package cs455.harvester.task;


public interface Task {
	public String getURL();
	public int getType();
}
