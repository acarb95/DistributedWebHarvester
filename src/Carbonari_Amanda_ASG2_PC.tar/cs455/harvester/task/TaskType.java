package cs455.harvester.task;

public class TaskType {
	public static final int HAND_OFF_TASK = 2;
	public static final int CRAWL_TASK = 3;
}
